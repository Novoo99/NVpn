# N VPN - Professional Android VPN Client

## Quick Build (Recommended)

### Windows / macOS / Linux

1. Download `NVPN_Source.zip`
2. Extract it
3. Open terminal in the extracted folder (`NVPN`)
4. Run:

```bash
# Windows:
gradlew.bat assembleRelease

# macOS / Linux:
chmod +x gradlew
./gradlew assembleRelease
```

APK will be ready at:
```
app/build/outputs/apk/release/app-release-unsigned.apk
```

### Sign the APK (one time)

```bash
# Generate keystore (first time only)
keytool -genkey -v -keystore nvpn-release.keystore -alias nvpn -keyalg RSA -keysize 2048 -validity 10000

# Sign APK
apksigner sign --ks nvpn-release.keystore --out NVPN-v1.0.apk app-release-unsigned.apk
```

---

## Features
- Material You + Dark Mode
- Xray Core (VLESS / VMESS / Trojan / Reality)
- Auto server list from GitHub
- Professional UI with Bottom Sheet
- Full VpnService implementation
- Speed & time display

**Production Ready** - No hardcoded servers.

## Requirements
- Android Studio (recommended) or Gradle 8.5+
- JDK 11+
- Android SDK 34

---

**Enjoy your professional VPN!**