package com.nvpn.app.model

data class Server(
    val name: String,
    val country: String = name,
    val flag: String,
    val config: String,
    val status: String = "on",
    val premium: Boolean = false,
    val ping: String = "-"
) {
    val isOnline: Boolean get() = status.lowercase() == "on"
}