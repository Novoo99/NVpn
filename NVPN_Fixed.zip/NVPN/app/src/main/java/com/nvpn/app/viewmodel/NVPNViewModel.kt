package com.nvpn.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nvpn.app.data.ServerRepository
import com.nvpn.app.model.Server
import com.nvpn.app.service.NVPNService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class NVPNUiState(
    val isConnected: Boolean = false,
    val currentServer: Server? = null,
    val downloadSpeed: String = "0 KB/s",
    val uploadSpeed: String = "0 KB/s",
    val connectionTime: String = "00:00:00",
    val servers: List<Server> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class NVPNViewModel : ViewModel() {
    private val repository = ServerRepository()
    
    private val _uiState = MutableStateFlow(NVPNUiState())
    val uiState: StateFlow<NVPNUiState> = _uiState.asStateFlow()

    private var startTime: Long = 0
    private var timerJob: kotlinx.coroutines.Job? = null

    init {
        fetchServers()
    }

    fun fetchServers() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            try {
                val servers = repository.fetchServers()
                _uiState.value = _uiState.value.copy(
                    servers = servers,
                    isLoading = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = e.message
                )
            }
        }
    }

    fun refreshServers() {
        fetchServers()
    }

    fun selectServer(server: Server) {
        if (!server.isOnline) return
        _uiState.value = _uiState.value.copy(currentServer = server)
    }

    fun connect(server: Server) {
        if (!server.isOnline) return
        
        _uiState.value = _uiState.value.copy(
            isConnected = true,
            currentServer = server,
            downloadSpeed = "1.2 MB/s",
            uploadSpeed = "480 KB/s",
            connectionTime = "00:00:00"
        )
        
        startTime = System.currentTimeMillis()
        startTimer()
        
        // Start VPN Service here
        // NVPNService.startVpn(context, server)
    }

    fun disconnect() {
        timerJob?.cancel()
        _uiState.value = _uiState.value.copy(
            isConnected = false,
            downloadSpeed = "0 KB/s",
            uploadSpeed = "0 KB/s",
            connectionTime = "00:00:00"
        )
        
        // Stop VPN Service
        // NVPNService.stopVpn(context)
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_uiState.value.isConnected) {
                val elapsed = System.currentTimeMillis() - startTime
                val seconds = (elapsed / 1000) % 60
                val minutes = (elapsed / (1000 * 60)) % 60
                val hours = (elapsed / (1000 * 60 * 60)) % 24
                
                val timeStr = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                
                // Simulate speed changes
                val down = (1200 + (Math.random() * 800)).toInt()
                val up = (300 + (Math.random() * 300)).toInt()
                
                _uiState.value = _uiState.value.copy(
                    connectionTime = timeStr,
                    downloadSpeed = "$down KB/s",
                    uploadSpeed = "$up KB/s"
                )
                
                delay(1500)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}