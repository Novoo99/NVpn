package com.nvpn.app

import android.app.Application
import android.content.Context
import androidx.work.Configuration
import androidx.work.WorkManager

class NVPNApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: NVPNApplication
            private set
    }
}