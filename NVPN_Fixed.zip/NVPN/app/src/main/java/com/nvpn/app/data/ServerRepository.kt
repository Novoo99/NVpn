package com.nvpn.app.data

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.nvpn.app.model.Server
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class ServerRepository {
    private val gson = Gson()
    private val serverUrl = "https://raw.githubusercontent.com/Novoo99/NVpn/refs/heads/main/nvpn.json"

    suspend fun fetchServers(): List<Server> = withContext(Dispatchers.IO) {
        try {
            val connection = (URL(serverUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15000
                readTimeout = 15000
            }
            
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            
            // The JSON is an array of objects but may need parsing
            val type = object : TypeToken<List<Server>>() {}.type
            gson.fromJson(response, type) ?: emptyList()
        } catch (e: Exception) {
            // Fallback to empty or cached if needed
            emptyList()
        }
    }
}