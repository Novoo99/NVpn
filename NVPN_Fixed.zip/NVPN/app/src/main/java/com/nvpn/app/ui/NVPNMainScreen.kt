package com.nvpn.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nvpn.app.model.Server
import com.nvpn.app.viewmodel.NVPNViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NVPNMainScreen(viewModel: NVPNViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val bottomSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showServers by remember { mutableStateOf(false) }

    val isConnected = uiState.isConnected
    val currentServer = uiState.currentServer
    val downloadSpeed = uiState.downloadSpeed
    val uploadSpeed = uiState.uploadSpeed
    val connectionTime = uiState.connectionTime
    val servers = uiState.servers
    val isLoading = uiState.isLoading

    // Background
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "N VPN",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
                IconButton(onClick = { viewModel.refreshServers() }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            // Status Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Connection Status
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isConnected) Color(0xFF4CAF50) else Color(0xFFFF5252)
                                )
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (isConnected) "CONNECTED" else "DISCONNECTED",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = if (isConnected) Color(0xFF4CAF50) else Color(0xFFFF5252)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Current Server Info
                    if (currentServer != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = currentServer.flag,
                                fontSize = 48.sp
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = currentServer.name,
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = currentServer.country,
                                    color = Color.Gray,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    } else {
                        Text(
                            "Select a server to connect",
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Stats Row
                    if (isConnected) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            StatItem("Download", downloadSpeed, Icons.Default.Download)
                            StatItem("Upload", uploadSpeed, Icons.Default.Upload)
                            StatItem("Time", connectionTime, Icons.Default.Timer)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(48.dp))

            // Big Connect Button
            val buttonScale by animateFloatAsState(
                targetValue = if (isConnected) 0.95f else 1f,
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                label = "connectButton"
            )

            Button(
                onClick = {
                    if (isConnected) {
                        viewModel.disconnect()
                    } else if (currentServer != null) {
                        viewModel.connect(currentServer)
                    } else {
                        showServers = true
                    }
                },
                modifier = Modifier
                    .size(160.dp)
                    .scale(buttonScale),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isConnected) Color(0xFFFF5252) else Color(0xFF6750A4)
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 12.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (isConnected) Icons.Default.PowerSettingsNew else Icons.Default.Power,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isConnected) "DISCONNECT" else "CONNECT",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            // Server Selection Button
            OutlinedButton(
                onClick = { showServers = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
            ) {
                Icon(Icons.Default.Public, contentDescription = null)
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = if (currentServer != null) "Change Server" else "Select Server",
                    fontSize = 18.sp
                )
            }
        }
    }

    // Server Bottom Sheet
    if (showServers) {
        ModalBottomSheet(
            onDismissRequest = { showServers = false },
            sheetState = bottomSheetState,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            ServerListBottomSheet(
                servers = servers,
                isLoading = isLoading,
                onServerSelected = { server ->
                    scope.launch {
                        bottomSheetState.hide()
                        showServers = false
                        viewModel.selectServer(server)
                    }
                },
                onRefresh = {
                    viewModel.refreshServers()
                }
            )
        }
    }
}

@Composable
fun StatItem(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color(0xFF6750A4),
            modifier = Modifier.size(22.dp)
        )
        Text(
            text = value,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color.Gray
        )
    }
}

@Composable
fun ServerListBottomSheet(
    servers: List<Server>,
    isLoading: Boolean,
    onServerSelected: (Server) -> Unit,
    onRefresh: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Servers",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
            )
            IconButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh Servers")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(servers) { server ->
                    ServerItem(
                        server = server,
                        onClick = { 
                            if (server.isOnline) {
                                onServerSelected(server)
                            } else {
                                // Show offline toast in real app
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ServerItem(server: Server, onClick: () -> Unit) {
    val isOnline = server.isOnline
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = isOnline, onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (isOnline) MaterialTheme.colorScheme.surfaceVariant else Color(0xFF2C2C2E)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = server.flag,
                fontSize = 36.sp
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = server.name,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = if (isOnline) Color.White else Color.Gray
                )
                Text(
                    text = server.country,
                    color = if (isOnline) Color.Gray else Color(0xFF777777),
                    fontSize = 13.sp
                )
            }
            
            if (server.premium) {
                Surface(
                    color = Color(0xFFFFD700),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        "PREMIUM",
                        color = Color.Black,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(horizontalAlignment = Alignment.End) {
                if (isOnline) {
                    Text(
                        text = server.ping,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF4CAF50)
                    )
                } else {
                    Text(
                        "OFFLINE",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}